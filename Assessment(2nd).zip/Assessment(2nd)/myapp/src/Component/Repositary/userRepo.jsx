import React from "react";
import "./repostyle.css"

export default function RepoList({ repos, isGrid }) {
  return (
    <div className={isGrid ? "grid-container" : "list-container"}>
      {repos.map((repo) => (
        <div key={repo.id} className="repo-card">
          <h3>{repo.name}</h3>
          <p>{repo.description || "No description provided."}</p><br />
          <span>stars : {repo.stargazers_count}</span>&nbsp;&nbsp;
          <span>forks : {repo.forks_count}</span>
        </div>
      ))}
    </div>
  );
}
